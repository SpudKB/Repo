import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class View extends JFrame {//epidei exei extends JFrame den xreiazete na dilwsw neo JFrame i class i idia einai JFrame antikeimeno apo oti katalaba
    //ara kai sto View() den iparxei logos na kanw Frame.add(Button) mporw na kanw sketo add(Button)
    private JButton addErgButton = new JButton("ADD");
    private JButton deleteErgButton = new JButton("DELETE");
    private JButton printErgButton = new JButton("PRINT");
    private JButton closeButton = new JButton("CLOSE");

//dilosi buttons (edw tha dilona kathe allo jobject)

    View() {

        setSize(600, 200);//megethos parathirou
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);//To x tou parathirou na klinei to programma
        setLayout(new FlowLayout());//pos tha einai ta koumpia sto parathiro anti gia FlowLayout mporw na balw allous tropous

        add(addErgButton);//bazw to addErgButton sto frame

        add(deleteErgButton);

        add(printErgButton);

        add(closeButton);




    }

    void addCloseListener(ActionListener listenForCloseButton) {
        closeButton.addActionListener(listenForCloseButton);
    }
    void addAddListener(ActionListener listenForAddButton) {
        addErgButton.addActionListener(listenForAddButton);
    }
    void addPrintListener(ActionListener listenForPrintButton) {printErgButton.addActionListener(listenForPrintButton);
    }
    void addDeleteListener(ActionListener listenForDeleteButton) {deleteErgButton.addActionListener(listenForDeleteButton);
    }
    //dilwsi listener px:
    //void onomaListener(ActionListener OnomaTouActionListener){buttonGiaToListener.addActionListener(OnomaTouActionListener);


}