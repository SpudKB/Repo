import java.util.ArrayList;

public class Model {
   private  ArrayList<Erg> ergazomenoi = new ArrayList<>();
   private int arithmosErg = 0;


    public void addErgazomeno(String name,int hours)
    {
        arithmosErg++;//gia automati arithmisi
        ergazomenoi.add(new Erg(arithmosErg,name, hours));//new thesi sto ArrayList ergazomenoi kai mesa o constructor tou Erg

    }

    public String getErgazomenoiString()
    {
        String ergList= "";//arxikopoiisi string
        for(int i=0;i<ergazomenoi.size();i++) {
            String temp = ergazomenoi.get(i).printErg();//bazw ta stoixeia tou ergazomenou stin thesi i sto temp
            ergList+=temp+"\n";//bazw to temp san sinexeia tou ergList kai meta allagi grammis
        }
        return ergList;

    }

    public void deleteErgazomeno(int ergForDelete)
    {
        ergForDelete--;//i array ksekinaei apo 0 i arithmisi apo 1
        ergazomenoi.remove(ergForDelete);// remove ton ergazomeno stin thesi ergForDelete
        while(ergForDelete<ergazomenoi.size())//ksanakanei tin automati arithmisi
        {
            ergazomenoi.get(ergForDelete).setArithmo(ergForDelete+1);//kanei ton arithmo tou ergazomenou ergForDelete(se autin ti stigmi einai idio me tin thesi tou) ara me +1 mpenei stin swsti seira
            ergForDelete++;
        }
    }

}
