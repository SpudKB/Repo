import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private View theView; //neo view me onoma theView
    private Model theModel;//neo model me onoma theModel


    public Controller(View theView, Model theModel) {//constructor tou Controller
        this.theView = theView;//to this.theView einai to view tou controller to allo tou constructor
        this.theModel = theModel;

        this.theView.addCloseListener(new closeListener());
        this.theView.addAddListener(new addListener());
        this.theView.addPrintListener(new printListener());
        this.theView.addDeleteListener(new deleteListener());
        //kalw tis methodous gia action listener apo to view kai bazw stis () tis class pou einai pio katw pou lene ti ginete otan pataw to koumpi

    }

    static class closeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(1);//close program


        }

    }

    class addListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            String nameInput = JOptionPane.showInputDialog("Onoma");//to parathiro pou zitaei onoma
            try {//dokimase na trekseis auto
                String hoursInput = JOptionPane.showInputDialog("Wres");//to parathiro pou zitaei wres
                int hoursInt = Integer.parseInt(hoursInput);//metatropi tous string se int
                theModel.addErgazomeno(nameInput,hoursInt);//kalw to addergazomeno tou model mas kai bazw mesa onoma kai wres
            }
            catch(Exception ex) {//an kati paei lathos sto try kane auto
                JOptionPane.showMessageDialog(null, "WRES PREPEI NA EINAI ARITHMOS");
            }

        }
    }

    class printListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, theModel.getErgazomenoiString());//parathiro me tin lista pou tin pernei apo to getErgazomenoiString()

        }

    }

    class deleteListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, theModel.getErgazomenoiString());//pali i lista
            try {
                String temp = JOptionPane.showInputDialog("Dialekse arithmo ergazomenou");//parathiro pou zita arithmo erg
                int ergForDelete = Integer.parseInt(temp);//string se int
                theModel.deleteErgazomeno(ergForDelete);//kalei class tou model
            }
            catch(Exception ex){//mporw na onomasw to Exception pali ex giati einai se alli class
                JOptionPane.showMessageDialog(null, "PREPEI NA EINAI ARITHMOS");
            }
            //TODO ti tha ginei otan kanw delete me adeia lista
        }

    }


}