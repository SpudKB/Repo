public class Erg {

    private String onoma;
    private int wresErgasias,arErg;

    public Erg(int arithmosErg,String name,int wresErgasias) {//constructor
        arErg=arithmosErg;
        onoma=name;
        this.wresErgasias=wresErgasias;

    }
    public Erg() {//constructor

    }

    public void setName(String name){
        onoma=name;
    }
    public String getName(){
        return onoma;
    }

    public void setWres(int wres){
        wresErgasias=wres;
    }
    public int getWres(){
        return wresErgasias;
    }
    public void setArithmo(int arErg){//ama to kalesw tha xalasei tin automati arithmisi
        this.arErg=arErg;
    }
    public int getArithmo(){
        return arErg;
    }

    public String printErg(){

        return("Arithmos: "+arErg+"  Onoma: "+onoma+"  Wres: "+wresErgasias);//return auto to string
    }

}


