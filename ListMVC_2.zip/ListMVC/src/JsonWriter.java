import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class JsonWriter {

    private static void writeWithFormat(JSONObject jo) {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String jsonOutput = gson.toJson(jo);

            FileWriter file = new FileWriter("package.json");
            file.write(jsonOutput);
            file.flush();

            file.close();
        } catch (IOException ex2) {
            ex2.printStackTrace();
        }
    }

    public static void writeErgToJson(Erg ergazomenos) {
        try  {
            FileReader fr = new FileReader("package.json");
            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONArray array = (JSONArray) jo.get("workers");
            JSONObject jo2 = new JSONObject();

            jo2.put("id",ergazomenos.getArithmo());
            jo2.put("onoma",ergazomenos.getName());
            jo2.put("epwnimo",ergazomenos.getEpwnimo());
            jo2.put("wres",ergazomenos.getWres());
            array.add(jo2);
            jo.put("workers",array);

            writeWithFormat(jo);
            fr.close();
        }catch (FileNotFoundException f){
            System.out.println("FILE NOT FOUND");
        }catch(IOException ex2){
            ex2.printStackTrace();
        }catch(ParseException e){
            e.printStackTrace();
        }

    }
    public static void updateJson(int position)
    {
        try  {

            FileReader fr = new FileReader("package.json");
            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONArray array = (JSONArray) jo.get("workers");
            array.remove(position);

            writeWithFormat(jo);
            fr.close();

        }catch (FileNotFoundException f){
            System.out.println("FILE NOT FOUND");
        }catch (IOException ex2) {
            ex2.printStackTrace();
        } catch(ParseException e){
            e.printStackTrace();
        }
    }
}
