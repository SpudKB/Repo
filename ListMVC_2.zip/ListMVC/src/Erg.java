public class Erg {

    private String onoma;
    private String epwnimo;
    private int wresErgasias;
    private int arErg;
    private int eleutheresWres;

    public Erg(int arErg,String onoma,String epwnimo,int wresErgasias) {
        this.arErg=arErg;
        this.onoma=onoma;
        this.wresErgasias=wresErgasias;
        this.epwnimo=epwnimo;
        eleutheresWres=wresErgasias;

    }
    public void setName(String onoma){
        onoma=onoma;
    }
    public String getName(){
        return onoma;
    }

    public void setWres(int wresErgasias){
        this.wresErgasias=wresErgasias;
    }
    public int getWres(){
        return wresErgasias;
    }

    public void setArithmo(int arErg){//if use will ruin ordering and reordiring when delete employee
        this.arErg=arErg;
    }
    public int getArithmo(){
        return arErg;
    }

    public int getEleutheresWres() {
        return eleutheresWres;
    }

    public void setEpwnimo(String epwnimo){this.epwnimo=epwnimo;}
    public String getEpwnimo() {
        return epwnimo;
    }

    public void setEleutheresWres(int eleutheresWres) {
        this.eleutheresWres= eleutheresWres;
    }

    public String toString(){
        return ("Arithmos:"+arErg+" Onoma:"+onoma+" Epwnimo: "+epwnimo+" Wres:"+wresErgasias);
    }

}


