import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private View theView;
    private Model theModel;


    public Controller(View theView, Model theModel) {
        this.theView = theView;
        this.theModel = theModel;

        this.theView.addCloseListener(new closeListener());
        this.theView.addAddListener(new addListener());
        this.theView.addPrintListener(new printListener());
        this.theView.addDeleteListener(new deleteListener());
        this.theView.addGenerateListener(new generateListener());


    }

    static class closeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(1);


        }

    }

    class addListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            String nameInput = JOptionPane.showInputDialog("Onoma");
            String epwnimoInput=JOptionPane.showInputDialog("Epwnimo");
            try {
                String hoursInput = JOptionPane.showInputDialog("Wres");
                int hoursInt = Integer.parseInt(hoursInput);
                theModel.addErgazomeno(nameInput,epwnimoInput,hoursInt);
            }
            catch(Exception ex) {
                JOptionPane.showMessageDialog(null, "WRES PREPEI NA EINAI ARITHMOS");
            }

        }
    }

    class printListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if(!theModel.ergazomenoiIsEmpty())  {
                JOptionPane.showMessageDialog(null, theModel.getErgazomenoiString());
            }
            else {
                JOptionPane.showMessageDialog(null, "H LISTA EINAI ADEIA");
            }
        }

    }

    class deleteListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if(!theModel.ergazomenoiIsEmpty()) {
                JOptionPane.showMessageDialog(null, theModel.getErgazomenoiString());
                try {
                    String temp = JOptionPane.showInputDialog("Dialekse arithmo ergazomenou");
                    int ergForDelete = Integer.parseInt(temp);
                    theModel.deleteErgazomeno(ergForDelete);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "PREPEI NA EINAI ARITHMOS");
                }
            }
            else {
                JOptionPane.showMessageDialog(null, "H LISTA EINAI ADEIA");
            }


            }
        }
        class generateListener implements ActionListener {

            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, theModel.generateBardies());
            }

        }

    }


