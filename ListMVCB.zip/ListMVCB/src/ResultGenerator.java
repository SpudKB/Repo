public class ResultGenerator {
    public static void completeAddition(Bardia bardia,Ergazomenos ergazomenos,String onomaBardias){
        bardia.addToBardia(ergazomenos);
        bardia.setWresBardias(bardia.getWresBardias() - 8);
        ergazomenos.setEleutheresWres( ergazomenos.getEleutheresWres() - 8);
        ergazomenos.setAvailable(false);

    }

}
