import java.util.*;

public class Model {
    private ArrayList<Ergazomenos> ergazomenoi = new ArrayList<>();
    private ArrayList<Bardia> bardiesMera = new ArrayList<>();
    private ArrayList<Bardia> bardiesApogeuma = new ArrayList<>();
    private ArrayList<Bardia> bardiesNixta = new ArrayList<>();
    private int arithmosErg;


    public Model() {
        JsonReader.fillBardiesArrays(bardiesMera, bardiesApogeuma, bardiesNixta);
        JsonReader.fillErgArray(ergazomenoi);
    }
    public void saveMonth(int month){
        JsonWriter.saveMonth(bardiesMera,bardiesApogeuma,bardiesNixta,month);
    }


    public int getArithmosErg() {
        return arithmosErg;
    }

    public void addErgazomeno(String name, String epwnimo, int hours) {
        arithmosErg = ergazomenoi.size() + 1;
        ergazomenoi.add(new Ergazomenos(arithmosErg, name, epwnimo, hours));
        JsonWriter.writeErgToJson(ergazomenoi.get(arithmosErg - 1));

    }

    public String getErgazomenoiString() {
        String ergList = "";
        for (int i = 0; i < ergazomenoi.size(); i++) {
            String temp = ergazomenoi.get(i).toString();
            ergList += temp + "\n";
        }
        return ergList;

    }

    public void deleteErgazomeno(int ergForDelete) {
        ergForDelete--;
        ergazomenoi.remove(ergForDelete);
        // int keeper=ergForDelete;
        while (ergForDelete < ergazomenoi.size()) {
            ergazomenoi.get(ergForDelete).setArithmo(ergForDelete + 1);
            ergForDelete++;
        }
        JsonWriter.updateJson(ergazomenoi);

    }




    public boolean ergazomenoiIsEmpty() {
        return ergazomenoi.isEmpty();
    }


    public void generateBardies() {
        emptyBardies();



        if (bardiesMera.get(0).getWresBardias() <= (ergazomenoi.size() * 8)) {
            int dayCounter = 1;
            HashMap<String ,Integer>ligoteresWres=new HashMap<>();
            ligoteresWres.put("Mera",0);
            ligoteresWres.put("Apogeuma",0);
            ligoteresWres.put("Nixta",0);
            Integer[] shuffled = new Integer[ergazomenoi.size()];
            Integer[][] workedTable=new Integer[ergazomenoi.size()][3];
            for(int i =0;i<ergazomenoi.size();i++)
                for(int j=0;j<3;j++)
                {
                    workedTable[i][j]=0;
                }

            for (int i = 0; i < shuffled.length; i++) {
                shuffled[i] = i;
            }
            int counterErgazomenon;
            for (int j = 0; j < bardiesMera.size(); j++) {

                counterErgazomenon = -1;
                Collections.shuffle(Arrays.asList(shuffled));

                while (bardiesMera.get(j).getWresBardias() > 0) {
                    counterErgazomenon++;

                    if (counterErgazomenon == ergazomenoi.size()) {
                        counterErgazomenon = 0;
                        ligoteresWres.put("Mera", ligoteresWres.get("Mera") + 8);
                    }
                    if (ligoteresWres.get("Mera") == workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo()-1][0]){
                        if (ergazomenoi.get(shuffled[counterErgazomenon]).isAvailable()) {
                            ResultGenerator.completeAddition(bardiesMera.get(j), ergazomenoi.get(shuffled[counterErgazomenon]), "Mera");
                            workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo() - 1][0] = workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo() - 1][0] + 8;
                        }
                    }
                }

                counterErgazomenon = -1;
                Collections.shuffle(Arrays.asList(shuffled));
                while (bardiesApogeuma.get(j).getWresBardias() > 0) {
                    counterErgazomenon++;
                    if (counterErgazomenon == ergazomenoi.size()) {
                        ligoteresWres.put("Apogeuma", ligoteresWres.get("Apogeuma") + 8);
                        counterErgazomenon = 0;
                    }
                    if (ligoteresWres.get("Apogeuma") == workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo()-1][1]) {
                        if (ergazomenoi.get(shuffled[counterErgazomenon]).isAvailable()) {
                            ResultGenerator.completeAddition(bardiesApogeuma.get(j), ergazomenoi.get(shuffled[counterErgazomenon]), "Apogeuma");
                            workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo() - 1][1] = workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo() - 1][1] + 8;
                        }
                    }
                }

                counterErgazomenon = -1;
                Collections.shuffle(Arrays.asList(shuffled));
                while (bardiesNixta.get(j).getWresBardias() > 0) {
                    counterErgazomenon++;
                    if (counterErgazomenon == ergazomenoi.size()) {
                        ligoteresWres.put("Nixta", ligoteresWres.get("Nixta") + 8);
                        counterErgazomenon = 0;
                    }
                    if (ligoteresWres.get("Nixta") == workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo()-1][2]) {
                        if (ergazomenoi.get(shuffled[counterErgazomenon]).isAvailable()) {
                            ResultGenerator.completeAddition(bardiesNixta.get(j), ergazomenoi.get(shuffled[counterErgazomenon]), "Nixta");
                            workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo() - 1][2] = workedTable[ergazomenoi.get(shuffled[counterErgazomenon]).getArithmo() - 1][2] + 8;
                        }
                    }
                }

                if (dayCounter == 7) {
                    ergazomenoi.forEach(Ergazomenos::resetEleutheresWres);
                    dayCounter = 0;
                }
                dayCounter++;
                ergazomenoi.forEach(Ergazomenos::makeAvailable);
                ligoteresWres.put("Mera", 0);
                ligoteresWres.put("Apogeuma", 0);
                ligoteresWres.put("Nixta", 0);


            }

            String test2="Mera\n";
            for(int i=0;i<ergazomenoi.size();i++)
               test2+=ergazomenoi.get(i).getName()+" "+workedTable[i][0]+" ";
            test2+="\nApogeuma\n";
            for(int i=0;i<ergazomenoi.size();i++)
                test2+=ergazomenoi.get(i).getName()+" "+workedTable[i][1]+" ";
            test2+="\nNixta\n";
            for(int i=0;i<ergazomenoi.size();i++)
                test2+=ergazomenoi.get(i).getName()+" "+workedTable[i][2]+" ";
            System.out.println(test2+"\n\n\n");

        }


    }
    public String createStringForPrint(){
        String results = "";
        if (bardiesMera.get(0).getWresBardias() <= (ergazomenoi.size() * 8)) {

            ArrayList<String> result = new ArrayList<>();

            for (int i = 0; i < bardiesMera.size(); i++) {
                result.add("DAY " + (i + 1) + " \n" + "MERA\n" + bardiesMera.get(i).allErgsToString() + "APOGEUMA\n" + bardiesApogeuma.get(i).allErgsToString() + "BRADI\n" + bardiesNixta.get(i).allErgsToString() + "\n");
            }

            for (int i = 0; i < result.size(); i++) {
                results += result.get(i);
            }
        }else
            results="DEN EXEIS ARKETOUS ERGAZOMENOUS";
        return results;

    }

    public void loadBardies(int month){
        emptyBardies();
        JsonReader.loadBardiaArray(ergazomenoi,bardiesMera,bardiesApogeuma,bardiesNixta,month);

    }
    public void emptyBardies(){
        for (int i=0;i<bardiesMera.size();i++)
        {
            bardiesMera.get(i).getErgazomenosStinBardia().clear();
            bardiesMera.get(i).resetWres();
            bardiesApogeuma.get(i).getErgazomenosStinBardia().clear();
            bardiesApogeuma.get(i).resetWres();
            bardiesNixta.get(i).getErgazomenosStinBardia().clear();
            bardiesNixta.get(i).resetWres();
        }
    }
}

