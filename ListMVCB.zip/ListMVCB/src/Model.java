import java.util.ArrayList;
import java.util.Random;

public class Model {
    private  ArrayList<Ergazomenos> ergazomenoi = new ArrayList<>();
    private ArrayList<Bardia> bardiesMera = new ArrayList<>();
    private ArrayList<Bardia> bardiesApogeuma = new ArrayList<>();
    private ArrayList<Bardia> bardiesNixta = new ArrayList<>();
    private int arithmosErg;

    public Model(){
        JsonReader.fillBardiesArrays(bardiesMera,bardiesApogeuma,bardiesNixta);
        JsonReader.fillErgArray(ergazomenoi);
    }


   public int getArithmosErg()
   {
       return arithmosErg;
   }

    public void addErgazomeno(String name,String epwnimo,int hours)
    {
        arithmosErg=ergazomenoi.size()+1;
        ergazomenoi.add(new Ergazomenos(arithmosErg,name,epwnimo, hours));
        JsonWriter.writeErgToJson(ergazomenoi.get(arithmosErg-1));

    }

    public String getErgazomenoiString()
    {
        String ergList= "";
        for(int i=0;i<ergazomenoi.size();i++) {
            String temp = ergazomenoi.get(i).toString();
            ergList+=temp+"\n";
        }
        return ergList;

    }

    public void deleteErgazomeno(int ergForDelete)
    {
        ergForDelete--;
        ergazomenoi.remove(ergForDelete);
       // int keeper=ergForDelete;
        while(ergForDelete<ergazomenoi.size())
        {
            ergazomenoi.get(ergForDelete).setArithmo(ergForDelete+1);
            ergForDelete++;
        }
        JsonWriter.updateJson(ergazomenoi);

    }

    public void changeHoursErg(int ergForChange, int newHours){

    }



    public boolean ergazomenoiIsEmpty()
    {
        return ergazomenoi.isEmpty();
    }
  


    public String generateBardies()
    {int x=1;
    String results="";
        for (int j = 0; j <bardiesMera.size(); j++) {
            while(bardiesMera.get(j).getWresBardias()>0) {

                Random randomGenerator = new Random();
                int randomInt = randomGenerator.nextInt(ergazomenoi.size());
                if (ergazomenoi.get(randomInt).isAvailable()) {
                    bardiesMera.get(j).addToBardia(ergazomenoi.get(randomInt));
                    bardiesMera.get(j).setWresBardias(bardiesMera.get(j).getWresBardias() - 8);
                    ergazomenoi.get(randomInt).setEleutheresWres(ergazomenoi.get(randomInt).getEleutheresWres() - 8);
                    ergazomenoi.get(randomInt).setAvailable(false);

                }
            }
            while(bardiesApogeuma.get(j).getWresBardias()>0) {
                System.out.println("here");
                Random randomGenerator = new Random();
                int randomInt = randomGenerator.nextInt(ergazomenoi.size());
                if (ergazomenoi.get(randomInt).isAvailable()) {

                    bardiesApogeuma.get(j).addToBardia(ergazomenoi.get(randomInt));
                    bardiesApogeuma.get(j).setWresBardias(bardiesApogeuma.get(j).getWresBardias() - 8);
                    ergazomenoi.get(randomInt).setEleutheresWres(ergazomenoi.get(randomInt).getEleutheresWres() - 8);
                    ergazomenoi.get(randomInt).setAvailable(false);

                }
            }
            while(bardiesNixta.get(j).getWresBardias()>0) {
                Random randomGenerator = new Random();
                int randomInt = randomGenerator.nextInt(ergazomenoi.size());
                if (ergazomenoi.get(randomInt).isAvailable()) {

                    bardiesNixta.get(j).addToBardia(ergazomenoi.get(randomInt));
                    bardiesNixta.get(j).setWresBardias(bardiesNixta.get(j).getWresBardias() - 8);
                    ergazomenoi.get(randomInt).setEleutheresWres(ergazomenoi.get(randomInt).getEleutheresWres() - 8);
                    ergazomenoi.get(randomInt).setAvailable(false);

                }
            }

            if(x==7) {
                ergazomenoi.forEach(Ergazomenos::resetEleutheresWres);
                x=0;
                      }
            x++;
            ergazomenoi.forEach(Ergazomenos::makeAvailable);
        }
        ArrayList<String> result=new ArrayList<>();

        for(int i=0;i<bardiesMera.size();i++)
        {
            result.add("DAY "+(i+1)+" \n"+"MERA\n"+bardiesMera.get(i).allErgsToString()+"APOGEUMA\n"+bardiesApogeuma.get(i).allErgsToString()+"BRADI\n"+bardiesNixta.get(i).allErgsToString()+"\n");
        }

        for(int i=0;i<result.size();i++)
        {
            results += result.get(i);
        }
        System.out.println(results);
        return results;
    }

}
