import java.util.ArrayList;

public class Bardia  {
    private int wresBardias;
    private int arxikesWres;
    private ArrayList<Ergazomenos> ergazomenosStinBardia = new ArrayList<>();


    public Bardia(int arxikesWres) {
        this.arxikesWres = arxikesWres;
        wresBardias=arxikesWres;
    }
    public void resetWres(){
        wresBardias=arxikesWres;
    }

    public String allErgsToString(){
        String x="";
        for (int i=0; i<ergazomenosStinBardia.size();i++)
            x+=ergazomenosStinBardia.get(i).toString()+"\n";
        return x;
    }


    public String ergNameToString(int i){
        return ergazomenosStinBardia.get(i).getName();
    }


    public int getWresBardias() {
        return wresBardias;
    }
    public void setWresBardias(int wresBardias) {
        this.wresBardias = wresBardias;
    }

    public void addToBardia(Ergazomenos ergazomenos) {
        ergazomenosStinBardia.add(ergazomenos);

    }

    public ArrayList<Ergazomenos> getErgazomenosStinBardia() {
        return ergazomenosStinBardia;

    }




}
