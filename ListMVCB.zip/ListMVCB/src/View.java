import java.awt.*;
 import java.awt.event.ActionListener;
import javax.swing.*;

public class View extends JFrame {
    private JButton addErgButton = new JButton("ADD");
    private JButton deleteErgButton = new JButton("DELETE");
    private JButton printErgButton = new JButton("PRINT");
    private JButton closeButton = new JButton("CLOSE");
    private JButton generateButton = new JButton("GENERATE");
    private JButton changeButton = new JButton("CHANGE HOURS OF EMPLOYEE"); // ANAFORA 5
    private JButton loadButton = new JButton("LOAD");
    View() {

        setSize(600, 200);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        add(addErgButton);
        add(deleteErgButton);
        add(printErgButton);
        add(generateButton);
        add(closeButton);
        add(changeButton); // anafora 5
        add(loadButton);
    }
    void addCloseListener(ActionListener listenForCloseButton) {
        closeButton.addActionListener(listenForCloseButton);
    }
    void addAddListener(ActionListener listenForAddButton) {
        addErgButton.addActionListener(listenForAddButton);
    }
    void addPrintListener(ActionListener listenForPrintButton) {printErgButton.addActionListener(listenForPrintButton); }
    void addDeleteListener(ActionListener listenForDeleteButton) {deleteErgButton.addActionListener(listenForDeleteButton); }
    void addGenerateListener(ActionListener listenForGenerateButton) {generateButton.addActionListener(listenForGenerateButton); }
    void addChangeListener(ActionListener listenforChangeButton) {changeButton.addActionListener(listenforChangeButton);} //anafora 5
    void addLoadListener(ActionListener listenforLoadButton) {loadButton.addActionListener(listenforLoadButton);}



}