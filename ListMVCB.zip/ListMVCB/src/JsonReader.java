import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;


public class JsonReader {
    public static void fillBardiesArrays(ArrayList<Bardia> meres,ArrayList<Bardia> apogeumata,ArrayList<Bardia> nixta){
        try(FileReader fr =new FileReader("requirements.json")) {

            int sk=0;
            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONArray array =(JSONArray)jo.get("employerSpecs");
            JSONObject jo2 = (JSONObject)array.get(0);

            int meresProg=((Number)jo2.get("weeks")).intValue();
            int wresMeras=((Number)jo2.get("dayworkforce")).intValue();
            int wresApogeumatos=((Number)jo2.get("eveningworkforce")).intValue();
            int wresNixtas=((Number)jo2.get("nightworkforce")).intValue();
            int wresSKMeras=((Number)jo2.get("daySK")).intValue();  //DHMIOURGHSA NEOOO ANAFORA
            int wresSKapogeuma=((Number)jo2.get("eveningSK")).intValue();
            int wresSKnixta=((Number)jo2.get("nightSK")).intValue();

            for(int i=0 ; i<meresProg;i++) {

                for (int j = 0; j < 7; j++) {
                    if (j == 5 || j == 6) {
                        meres.add(new Bardia(wresSKMeras));
                        apogeumata.add(new Bardia(wresSKapogeuma));
                        nixta.add(new Bardia(wresSKnixta));
                    } else {
                        meres.add(new Bardia(wresMeras));
                        apogeumata.add(new Bardia(wresApogeumatos));
                        nixta.add(new Bardia(wresNixtas));
                    }
                }

            }
        }catch (FileNotFoundException ex) {
            System.out.print("FILE NOT FOUND");

        } catch (IOException ex2) {
            ex2.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();

        }

    }

    public static void fillErgArray(ArrayList<Ergazomenos> ergazomenoi) {
        try (FileReader fr = new FileReader("requirements.json")) {

            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONArray array = (JSONArray) jo.get("workers");
            if(array!=null)
            {
                Iterator i = array.iterator();
                while (i.hasNext()) {
                    JSONObject jo2 = (JSONObject) i.next();
                    int id = ((Number) jo2.get("id")).intValue();
                    String onoma = (String) jo2.get("onoma");
                    String epwnimo = (String) jo2.get("epwnimo");
                    int wres = ((Number) jo2.get("wres")).intValue();
                    ergazomenoi.add(new Ergazomenos(id, onoma, epwnimo, wres));

                }
            }

        } catch (FileNotFoundException ex) {
            System.out.print("FILE NOT FOUND");

        } catch (IOException ex2) {
            ex2.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();

        }
    }
    public static void loadBardiaArray(ArrayList<Ergazomenos> ergazomenoi,ArrayList<Bardia> mera,ArrayList<Bardia> apogeuma,ArrayList<Bardia> bradi,int month) {
        try (FileReader fr = new FileReader("savedMonths.json")) {
            JSONParser parser = new JSONParser();
            Object obj  = parser.parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONObject minasJson = (JSONObject)jo.get(Integer.toString(month));


            if(minasJson!=null)
            {
                int employeeID;
                JSONArray arrayOfEmployees;
                for(int i=0;i<mera.size();i++)
                {
                    JSONObject tempJO = new JSONObject();
                    tempJO=(JSONObject)minasJson.get(Integer.toString(i+1));

                    arrayOfEmployees=(JSONArray) tempJO.get("Mera");

                    for(int j=0;j<arrayOfEmployees.size();j++)
                    {


                        JSONObject objectOfEmployee =(JSONObject)arrayOfEmployees.get(j);
                        employeeID=((Number)objectOfEmployee.get("id")).intValue();
                        mera.get(i).addToBardia(ergazomenoi.get(employeeID-1));
                    }

                    arrayOfEmployees=(JSONArray) tempJO.get("Apogeuma");
                    for(int j=0;j<arrayOfEmployees.size();j++)
                    {

                        JSONObject objectOfEmployee =(JSONObject)arrayOfEmployees.get(j);
                        employeeID=((Number)objectOfEmployee.get("id")).intValue();
                        apogeuma.get(i).addToBardia(ergazomenoi.get(employeeID-1));
                    }

                    arrayOfEmployees=(JSONArray) tempJO.get("Nixta");

                    for(int j=0;j<arrayOfEmployees.size();j++)
                    {



                        JSONObject objectOfEmployee =(JSONObject)arrayOfEmployees.get(j);
                        employeeID=((Number)objectOfEmployee.get("id")).intValue();
                        bradi.get(i).addToBardia(ergazomenoi.get(employeeID-1));

                    }

                }
            }else
                System.out.print("Month doesnt exist");

        }catch (FileNotFoundException ex) {
            System.out.print("FILE NOT FOUND");

        } catch (IOException ex2) {
            ex2.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();

        }

    }
    public static boolean savedMonthsIsNull(){

        try  {
            BufferedReader br = new BufferedReader(new FileReader("savedMonths.json"));
            if (br.readLine() == null) {
                return true;
            }
            else
                return false;


        }catch (FileNotFoundException ex) {
            System.out.print("FILE NOT FOUND");

        } catch (IOException ex2) {
            ex2.printStackTrace();
        }
        return true;

    }
}
