public class Erg {

    private String onoma;
    private int wresErgasias;
    private int arErg;
    private int eleutheresWres;

    public Erg(int arithmosErg,String name,int wresErgasias) {
        arErg=arithmosErg;
        onoma=name;
        this.wresErgasias=wresErgasias;
        eleutheresWres=wresErgasias;

    }
    public Erg() {

    }

    public void setName(String name){
        onoma=name;
    }
    public String getName(){
        return onoma;
    }

    public void setWres(int wres){
        wresErgasias=wres;
    }
    public int getWres(){
        return wresErgasias;
    }
    public void setArithmo(int arErg){//if use will ruin ordering and reordiring when delete employee
        this.arErg=arErg;
    }
    public int getArithmo(){
        return arErg;
    }
    public int getEleutheresWres() {
        return eleutheresWres;
    }
    public void setEleutheresWres(int eleutheresWres) {
        this.eleutheresWres= eleutheresWres;
    }

    public void printErg(){
        System.out.println("Arithmos:"+arErg+" Onoma:"+onoma+" Wres:"+wresErgasias);
    }

}


