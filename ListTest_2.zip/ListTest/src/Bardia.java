import java.util.ArrayList;

public class Bardia {
    private int wresBardias;
    private ArrayList<Erg> ergStinBardia= new ArrayList<>();

    public Bardia(int wresBardias) {
        this.wresBardias = wresBardias;

    }


    public String ergNameToString(int i){

        return ergStinBardia.get(i).getName();
    }


    public int getWresBardias() {
        return wresBardias;
    }

    public void setWresBardias(int wresBardias) {
        this.wresBardias = wresBardias;
    }

    public void addToBardia(Erg ergazomenos) {
        ergStinBardia.add(ergazomenos);

    }
    public ArrayList<Erg> getErgFromThesi() {
        return ergStinBardia;

    }


}
