
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        int xForChoice=0,wres,arithmosErg=0,xForDelete,bdomades,wresMeras,wresApogeumatos,wresNixtas;
        String name;
        Scanner scanner = new Scanner(System.in);
        ArrayList<Erg> ergazomenoi = new ArrayList<>();
        ArrayList<Erg> tempErgazomenoi = new ArrayList<>();
        ArrayList<Bardia> bardiesMera = new ArrayList<>();
        ArrayList<Bardia> bardiesApogeuma = new ArrayList<>();
        ArrayList<Bardia> bardiesNixta = new ArrayList<>();

        JSONObject parser = new JSONObject();
        try(FileReader fr =new FileReader("package.json")){
            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            // System.out.print(obj);
            bdomades=((Number)jo.get("Weeks")).intValue();
            bdomades=bdomades*7;
            wresMeras=((Number)jo.get("DayWorkforce")).intValue();
            wresApogeumatos=((Number)jo.get("EveningWorkforce")).intValue();
            wresNixtas=((Number)jo.get("NightWorkforce")).intValue();
            for(int i=0 ; i<7;i++)
            {
                bardiesMera.add(new Bardia(wresMeras));
                bardiesNixta.add(new Bardia(wresNixtas));
                bardiesApogeuma.add(new Bardia(wresApogeumatos));

            }

        }
        catch(FileNotFoundException ex){
            System.out.print("FILE NOT FOUND");

        }catch (IOException ex2) {
            ex2.printStackTrace();
        }catch(ParseException e){
            e.printStackTrace();;
        }




        while(xForChoice!=4) {
            System.out.println("1 add,2 delete,3 print ,4 generate,5 close");
            xForChoice = scanner.nextInt();
            switch (xForChoice) {
                case 1:
                    arithmosErg++;
                    System.out.println("Dwse onoma");
                    scanner.nextLine();
                    name = scanner.nextLine();
                    System.out.println("Dwse wres");
                    wres = scanner.nextInt();
                    ergazomenoi.add(new Erg(arithmosErg, name, wres));
                    break;
                case 2:
                    for (int i = 0; i < ergazomenoi.size(); i++)
                        ergazomenoi.get(i).printErg();
                    System.out.println("Dialekse arithmo");
                    xForDelete = scanner.nextInt();
                    xForDelete--;//array starts at 0 count of employee at 1
                    ergazomenoi.remove(xForDelete);

                    while (xForDelete < ergazomenoi.size()) {
                        ergazomenoi.get(xForDelete).setArithmo(xForDelete + 1);
                        xForDelete++;
                    }
                    break;

                case 3:

                    for (int i = 0; i < ergazomenoi.size(); i++) {
                        ergazomenoi.get(i).printErg();
                    }
                    break;
                case 4:
                    String test = "";
                    int counter =0;
                    for (int j = 0; j < bardiesMera.size(); j++) {
                        test+="DAY "+j+"\n";
                        for (int i = 0; i < ergazomenoi.size(); i++) {
                            if (bardiesMera.get(j).getWresBardias() > 0 && !bardiesMera.get(j).getErgFromThesi().contains(ergazomenoi.get(i)) && ergazomenoi.get(i).getEleutheresWres() > 8) {

                                        //System.out.println(j+" "+i);
                                        bardiesMera.get(j).addToBardia(ergazomenoi.get(i));
                                        ergazomenoi.get(i).setEleutheresWres(ergazomenoi.get(i).getEleutheresWres()-8);
                                        test += bardiesMera.get(j).ergNameToString(counter) + "\n";
                                        counter++;



                            }
                        }
                        counter=0;
                    }

                    System.out.println(test);
                    break;
                case 5:
                    System.exit(0) ;
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }







    }
}