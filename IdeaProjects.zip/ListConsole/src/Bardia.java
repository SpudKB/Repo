import java.util.ArrayList;

public class Bardia  {
    private int wresBardias;


    private ArrayList<Erg> ergStinBardia= new ArrayList<>();


    public Bardia(int wresBardias) {

            this.wresBardias = wresBardias;



    }



    public String allErgsToString(){
        String x="";
        for (int i=0; i<ergStinBardia.size();i++)
            x+=ergStinBardia.get(i).toString()+"\n";
        return x;
    }


    public int getWresBardias() {
        return wresBardias;
    }
    public void setWresBardias(int wresBardias) {
        this.wresBardias = wresBardias;
    }

    public void addToBardia(Erg ergazomenos) {
        ergStinBardia.add(ergazomenos);

    }

    public ArrayList<Erg> getErgStinBardia() {
        return ergStinBardia;

    }

}
