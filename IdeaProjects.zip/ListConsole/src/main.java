import java.util.ArrayList;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        int xForChoice=0,wres,arithmosErg,xForDelete;
        String name,epwnimo;
        Scanner scanner = new Scanner(System.in);
        ArrayList<Erg> ergazomenoi = new ArrayList<>();
        ArrayList<Bardia> bardiesMera = new ArrayList<>();
        ArrayList<Bardia> bardiesApogeuma = new ArrayList<>();
        ArrayList<Bardia> bardiesNixta = new ArrayList<>();

        JsonReader.fillBardiesArrays(bardiesMera,bardiesApogeuma,bardiesNixta);
        JsonReader.fillErgArray(ergazomenoi);






        while(xForChoice!=5) {
            System.out.println("1 add,2 delete,3 print ,4 generate,5 close");
            xForChoice = scanner.nextInt();
            switch (xForChoice) {
                case 1:
                    arithmosErg=ergazomenoi.size()+1;
                    System.out.println("Dwse onoma");
                    scanner.nextLine();
                    name = scanner.nextLine();
                    System.out.println("Dwse epwnimo");
                    epwnimo = scanner.nextLine();
                    System.out.println("Dwse wres");
                    wres = scanner.nextInt();
                    ergazomenoi.add(new Erg(arithmosErg, name,epwnimo, wres));
                    JsonWriter.writeErgToJson(ergazomenoi.get(arithmosErg-1));
                    break;
                case 2:
                    if(!ergazomenoi.isEmpty()) {
                        for (int i = 0; i < ergazomenoi.size(); i++)
                            System.out.println(ergazomenoi.get(i).toString());
                        System.out.println("Dialekse arithmo");
                        xForDelete = scanner.nextInt();
                        xForDelete--;//array starts at 0 count of employee at 1
                        int keeper=xForDelete;
                        ergazomenoi.remove(xForDelete);
                        while (xForDelete < ergazomenoi.size()) {
                            ergazomenoi.get(xForDelete).setArithmo(xForDelete + 1);
                            xForDelete++;
                        }
                        JsonWriter.updateJson(keeper);
                    }else
                    {
                        System.out.println("H LISTA EINAI ADEIA");
                    }
                    break;

                case 3:
                    if(!ergazomenoi.isEmpty())
                    {
                        for (int i = 0; i < ergazomenoi.size(); i++)
                            System.out.println(ergazomenoi.get(i).toString());
                    }else{
                        System.out.println("H LISTA EINAI ADEIA");
                    }
                    break;
                case 4:

                    int x=1;
                         for (int j = 0; j <bardiesMera.size(); j++) {

                            for (int i = 0; i < ergazomenoi.size(); i++) {
                                if (bardiesMera.get(j).getWresBardias() > 0 && ergazomenoi.get(i).isAvailable()) {
                                    bardiesMera.get(j).addToBardia(ergazomenoi.get(i));
                                    bardiesMera.get(j).setWresBardias(bardiesMera.get(j).getWresBardias() - 8);
                                    ergazomenoi.get(i).setEleutheresWres(ergazomenoi.get(i).getEleutheresWres() - 8);
                                    ergazomenoi.get(i).setAvailable(false);


                                } else if (bardiesApogeuma.get(j).getWresBardias() > 0 && ergazomenoi.get(i).isAvailable()) {
                                    bardiesApogeuma.get(j).addToBardia(ergazomenoi.get(i));
                                    bardiesApogeuma.get(j).setWresBardias(bardiesApogeuma.get(j).getWresBardias() - 8);
                                    ergazomenoi.get(i).setEleutheresWres(ergazomenoi.get(i).getEleutheresWres() - 8);
                                    ergazomenoi.get(i).setAvailable(false);

                                } else if (bardiesNixta.get(j).getWresBardias() > 0 && ergazomenoi.get(i).isAvailable()) {
                                    bardiesNixta.get(j).addToBardia(ergazomenoi.get(i));
                                    bardiesNixta.get(j).setWresBardias(bardiesNixta.get(j).getWresBardias() - 8);
                                    ergazomenoi.get(i).setEleutheresWres(ergazomenoi.get(i).getEleutheresWres() - 8);
                                    ergazomenoi.get(i).setAvailable(false);

                                }
                                if(x==7) {
                                    ergazomenoi.forEach(Erg::resetEleutheresWres);
                                    x=0;
                                }
                                ergazomenoi.get(i).setAvailable(true);
                            }

                             x++;

                        }


                    ArrayList<String> result=new ArrayList<>();
                    for(int i=0;i<bardiesApogeuma.size();i++)
                    {
                        result.add("DAY "+(i+1)+" \n"+"MERA\n"+bardiesMera.get(i).allErgsToString()+"APOGEUMA\n"+bardiesApogeuma.get(i).allErgsToString()+"BRADI\n"+bardiesNixta.get(i).allErgsToString()+"\n");

                    }

                    System.out.println("1 Olokliro, 2 Mera");
                    int showInput= scanner.nextInt();
                    switch (showInput) {
                        case 2:
                            System.out.println("Dwse mera");
                            int mera = scanner.nextInt();
                            System.out.println(result.get(mera - 1));
                            break;
                        case 1:
                            for(int i=0;i<result.size();i++) {
                                System.out.println(result.get(i));
                            }
                            break;
                        default:
                            System.out.println("lathos epilogi");
                    }
                    break;
                case 5:
                    System.exit(0) ;
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }







    }
}