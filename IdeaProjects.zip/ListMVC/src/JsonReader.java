import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;


public class JsonReader {
    public static void fillBardiesArrays(ArrayList<Bardia> meres,ArrayList<Bardia> apogeumata,ArrayList<Bardia> nixta){
        try(FileReader fr =new FileReader("requirements.json")) {

            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONArray array =(JSONArray)jo.get("employerSpecs");
            JSONObject jo2 = (JSONObject)array.get(0);

            int meresProg=((Number)jo2.get("weeks")).intValue()*7;
            int wresMeras=((Number)jo2.get("dayworkforce")).intValue();
            int wresApogeumatos=((Number)jo2.get("eveningworkforce")).intValue();
            int wresNixtas=((Number)jo2.get("nightworkforce")).intValue();

            for(int i=0 ; i<meresProg;i++)
            {
                meres.add(new Bardia(wresMeras));
                apogeumata.add(new Bardia(wresNixtas));
                nixta.add(new Bardia(wresApogeumatos));

            }

        }catch (FileNotFoundException ex) {
            System.out.print("FILE NOT FOUND");

        } catch (IOException ex2) {
            ex2.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();

        }

    }

    public static void fillErgArray(ArrayList<Ergazomenos> ergazomenoi) {
        try (FileReader fr = new FileReader("requirements.json")) {

            Object obj = new JSONParser().parse(fr);
            JSONObject jo = (JSONObject) obj;
            JSONArray array = (JSONArray) jo.get("workers");
            if(array!=null)
            {
                Iterator i = array.iterator();
                while (i.hasNext()) {
                    JSONObject jo2 = (JSONObject) i.next();
                    int id = ((Number) jo2.get("id")).intValue();
                    String onoma = (String) jo2.get("onoma");
                    String epwnimo = (String) jo2.get("epwnimo");
                    int wres = ((Number) jo2.get("wres")).intValue();
                    ergazomenoi.add(new Ergazomenos(id, onoma, epwnimo, wres));

                }
            }

        } catch (FileNotFoundException ex) {
            System.out.print("FILE NOT FOUND");

        } catch (IOException ex2) {
            ex2.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();

        }
    }
}
