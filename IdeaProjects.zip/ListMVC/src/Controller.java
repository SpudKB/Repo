import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private View theView;
    private Model theModel;


    public Controller(View theView, Model theModel) {
        this.theView = theView;
        this.theModel = theModel;

        this.theView.addCloseListener(new closeListener());
        this.theView.addAddListener(new addListener());
        this.theView.addPrintListener(new printListener());
        this.theView.addDeleteListener(new deleteListener());
        this.theView.addGenerateListener(new generateListener());


    }

    static class closeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(1);


        }

    }

    class addListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            JTextField field1 = new JTextField();
            JTextField field2 = new JTextField();
            JTextField field3 = new JTextField();

            Object[] message = {
                    "Onoma:", field1,
                    "Epwnimo", field2,
                    "Wres", field3,

            };
            int option = JOptionPane.showConfirmDialog(null, message, "DWSE STOIXEIA ERGAZOMENOU", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION)
            {
                String name = field1.getText();
                String surname = field2.getText();
                try {
                    int hours = Integer.parseInt(field3.getText());
                    theModel.addErgazomeno(name,surname,hours);
                }catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"WRES PREPEI NA EINAI ARITHMOS");
                }


            }

        }
    }

    class printListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if(!theModel.ergazomenoiIsEmpty())  {
                JOptionPane.showMessageDialog(null, theModel.getErgazomenoiString());
            }
            else {
                JOptionPane.showMessageDialog(null, "H LISTA EINAI ADEIA");
            }
        }

    }

    class deleteListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if(!theModel.ergazomenoiIsEmpty()) {
                String string=theModel.getErgazomenoiString()+"\n DWSE ARITHMO ERGAZOMENOU";
                JTextField field1 = new JTextField();
                Object[] message= {string,field1};
                try {
                    int option = JOptionPane.showConfirmDialog(null, message, "DWSE ARITHMO ERGAZOMENOU", JOptionPane.OK_CANCEL_OPTION);
                    if (option == JOptionPane.OK_OPTION)
                    {
                        int ergForDelete = Integer.parseInt(field1.getText());
                        theModel.deleteErgazomeno(ergForDelete);
                    }
                } catch  (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "PREPEI NA EINAI ARITHMOS");
                }
            }
            else {
                JOptionPane.showMessageDialog(null, "H LISTA EINAI ADEIA");
            }


            }
        }
        class generateListener implements ActionListener {

            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, theModel.generateBardies());
            }

        }

    }


