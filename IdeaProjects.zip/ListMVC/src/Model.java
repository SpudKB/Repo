import java.util.ArrayList;

public class Model {
    private  ArrayList<Ergazomenos> ergazomenoi = new ArrayList<>();
    private ArrayList<Bardia> bardiesMera = new ArrayList<>();
    private ArrayList<Bardia> bardiesApogeuma = new ArrayList<>();
    private ArrayList<Bardia> bardiesNixta = new ArrayList<>();
    private int arithmosErg;

    public Model(){

        JsonReader.fillBardiesArrays(bardiesMera,bardiesApogeuma,bardiesNixta);
        JsonReader.fillErgArray(ergazomenoi);


    }


   public int getArithmosErg()
   {
       return arithmosErg;
   }

    public void addErgazomeno(String name,String epwnimo,int hours)
    {
        arithmosErg=ergazomenoi.size()+1;
        ergazomenoi.add(new Ergazomenos(arithmosErg,name,epwnimo, hours));
        JsonWriter.writeErgToJson(ergazomenoi.get(arithmosErg-1));

    }

    public String getErgazomenoiString()
    {
        String ergList= "";
        for(int i=0;i<ergazomenoi.size();i++) {
            String temp = ergazomenoi.get(i).toString();
            ergList+=temp+"\n";
        }
        return ergList;

    }

    public void deleteErgazomeno(int ergForDelete)
    {
        ergForDelete--;
        ergazomenoi.remove(ergForDelete);
        int keeper=ergForDelete;
        while(ergForDelete<ergazomenoi.size())
        {
            ergazomenoi.get(ergForDelete).setArithmo(ergForDelete+1);
            ergForDelete++;
        }
        JsonWriter.updateJson(ergazomenoi);

    }
    public boolean ergazomenoiIsEmpty()
    {
        return ergazomenoi.isEmpty();
    }

    public String generateBardies()
    {
        String test = "";
        int counter =0;
        for (int j = 0; j < bardiesMera.size(); j++) {
            test+="DAY "+(j+1)+"\n";
            for (int i = 0; i < ergazomenoi.size(); i++) {
                if (!bardiesMera.get(j).getErgazomenosStinBardia().contains(ergazomenoi.get(i))&&bardiesMera.get(j).getWresBardias() > 0  && ergazomenoi.get(i).getEleutheresWres() >= 8) {
                    bardiesMera.get(j).addToBardia(ergazomenoi.get(i));
                    ergazomenoi.get(i).setEleutheresWres(ergazomenoi.get(i).getEleutheresWres()-8);
                    test += bardiesMera.get(j).ergNameToString(counter) + " ";
                    counter++;



                }
            }
            test+="\n";
            counter=0;
        }
        return test;
    }

}
