import java.util.ArrayList;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        int xForChoice=0,wres,arithmosErg=0,xForDelete;
        String name;
        Scanner scanner = new Scanner(System.in);
        ArrayList<Erg> ergazomenoi = new ArrayList<Erg>();
        while(xForChoice!=4) {
            System.out.println("1 add,2 delete,3 print ,4 close");
            xForChoice = scanner.nextInt();
            switch (xForChoice) {
                case 1:
                    arithmosErg++;
                    System.out.println("Dwse onoma");
                    scanner.nextLine();
                    name=scanner.nextLine();
                    System.out.println("Dwse wres");
                    wres=scanner.nextInt();
                    ergazomenoi.add(new Erg(arithmosErg,name, wres));
                    break;
                case 2:
                    for(int i=0;i<ergazomenoi.size();i++)
                        ergazomenoi.get(i).printErg();
                    System.out.println("Dialekse arithmo");
                    xForDelete=scanner.nextInt();
                    xForDelete--;//array starts at 0 count of employee at 1
                    ergazomenoi.remove(xForDelete);

                    while(xForDelete<ergazomenoi.size())
                        {
                            ergazomenoi.get(xForDelete).setArithmo(xForDelete+1);
                            xForDelete++;
                        }
                    break;

                case 3:
                    for(int i=0;i<ergazomenoi.size();i++) {
                        ergazomenoi.get(i).printErg();
                    }
                    break;
                case 4:
                    System.exit(0) ;
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }





    }
}